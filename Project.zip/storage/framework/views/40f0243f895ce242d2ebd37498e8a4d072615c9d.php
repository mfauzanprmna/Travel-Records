    
    <form action="<?php echo e(route('catper.destroy', $catper->id)); ?>" method="post">
        <div class="modal-body">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <h5 class="text-center">Anda yakin ingin menghapus data ini ?</h5>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal" class="close">Cancel</button>
            <button type="submit" class="btn btn-danger">Yes, Delete Data</button>
        </div>
    </form>
<?php /**PATH C:\xampp\htdocs\Project\resources\views/user/catper/delete.blade.php ENDPATH**/ ?>