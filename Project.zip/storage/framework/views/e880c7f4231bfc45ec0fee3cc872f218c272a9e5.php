
<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('main'); ?>
    <style>
        .pilih {
            transition: .5s;
        }

        .pilih:hover {
            transform: scale(1.03);
            transition: .5s;
            box-shadow: 9px 9px 5px 0 rgba(0, 0, 0, 0.03);
        }

    </style>

    <div class="panel-header " style="background-image: linear-gradient(#7a74fc, #6C63FF);">
        <div class="page-inner py-5">
            <div class="d-flex align-items-left align-items-md-center flex-column flex-md-row">
                <div>
                    <h2 class="text-white pb-2 fw-bold">Dashboard </h2>
                    <h5 class="text-white op-7 mb-2"><?php echo e(Carbon\Carbon::now()->isoFormat('dddd, D MMMM YYYY')); ?></h5>
                </div>
            </div>
        </div>
    </div>

    <div class="page-inner mt--5">
        <div class="card full-height">
            <div class="card-body">
                <div>
                    <h3 class="pb-2 fw-bold"><?php echo e($greetings); ?>, <?php echo e(Auth::user()->name); ?></h3>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6">
                <a href="<?php echo e(route('catper.index')); ?>" style="text-decoration:none; color:inherit;">
                    <div class="pilih card full-height">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-5 text-center">
                                    <img src="<?php echo e(asset('img/Notes_Monochromatic.png')); ?>" alt="" width="50%">
                                </div>
                                <div class="col-md-7">
                                    <div class="card-title">Catatan Perjalanan</div>
                                    <p>Tempat untuk melihat, menambahkan dan mengupdate data Catatan Perjalanan selama
                                        Pandemi</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-md-6">
                <a href="<?php echo e(route('akun.index')); ?>" style="text-decoration:none; color:inherit;">
                    <div class="pilih card full-height">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-5 text-center">
                                    <img src="<?php echo e(asset('img/User interface_Monochromatic.png')); ?>" alt="" width="50%">
                                </div>
                                <div class="col-md-7">
                                    <div class="card-title">Update Akun</div>
                                    <p>Tempat untuk meengubah data Akun</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </a>
            </div>
        </div>

        <div class="container">
            <h1>Riwayat Catatan Perjalanan</h1>
            <?php $__currentLoopData = $riwayat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card full-height">
                    <div class="card-body">
                        <div class="d-flex justify-content-between flex-wrap">
                            <h3>Lokasi : <?php echo e($item->lokasi); ?></h3>
                            <h6>Suhu Tubuh : <?php echo e($item->suhu); ?> &#8451;</h6>
                        </div>
                        <h5 class="op-7">
                            <?php echo e(Carbon\Carbon::createFromFormat('Y-m-d', $item->tanggal)->isoFormat('dddd, D MMMM YYYY')); ?>

                            <?php echo e($item->waktu); ?></h5>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="pagination justify-content-center">
                <?php echo e($riwayat->links()); ?>

            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Project\resources\views/dashboard.blade.php ENDPATH**/ ?>