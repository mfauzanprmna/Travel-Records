    <script src="https://cdnjs.cloudflare.com/ajax/libs/parsley.js/2.9.2/parsley.min.js"
        integrity="sha512-eyHL1atYNycXNXZMDndxrDhNAegH2BDWt1TmkXJPoGf1WLlNYt08CSjkqF5lnCRmdm3IrkHid8s2jOUY4NIZVQ=="
        crossorigin="anonymous" referrerpolicy="no-referrer"></script>

    
    <!-- Modal -->
    <div class="modal fade show" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        style="display: block">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-body">
                    <form action="" class="contact-form">
                        <?php echo csrf_field(); ?>
                        

                        <div class="form-section">
                            <div class="row">
                                <div class="col-md-4 form-group">
                                    <h3 style="margin-left: -10px">Instagram</h3>
                                    <label class="font-weight-bold">Nama</label>
                                    <input type="date" class="form-control" name="tanggal"
                                        value="<?php echo e(old('tanggal')); ?>" placeholder="Masukkan No Induk">

                                    <label class="font-weight-bold">Link</label>
                                    <input type="date" class="form-control" name="tanggal"
                                        value="<?php echo e(old('tanggal')); ?>" placeholder="Masukkan No Induk">
                                </div>

                                <div class="col-md-4 form-group">
                                    <h3 style="margin-left: -10px">Facebook</h3>
                                    <label class="font-weight-bold">Nama</label>
                                    <input type="date" class="form-control" name="tanggal"
                                        value="<?php echo e(old('tanggal')); ?>" placeholder="Masukkan No Induk">

                                    <label class="font-weight-bold">Link</label>
                                    <input type="date" class="form-control" name="tanggal"
                                        value="<?php echo e(old('tanggal')); ?>" placeholder="Masukkan No Induk">
                                </div>

                                <div class="col-md-4 form-group">
                                    <h3 style="margin-left: -10px">Twitter</h3>
                                    <label class="font-weight-bold">Nama</label>
                                    <input type="date" class="form-control" name="tanggal"
                                        value="<?php echo e(old('tanggal')); ?>" placeholder="Masukkan No Induk">

                                    <label class="font-weight-bold">Link</label>
                                    <input type="date" class="form-control" name="tanggal"
                                        value="<?php echo e(old('tanggal')); ?>" placeholder="Masukkan No Induk">
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-link" data-dismiss="modal">Lewati</button>
                    <button type="button" class="btn btn-primary">Save changes</button>
                </div>
            </div>
        </div>
    </div>
    
<?php /**PATH C:\xampp\htdocs\Project\resources\views/template/modal.blade.php ENDPATH**/ ?>